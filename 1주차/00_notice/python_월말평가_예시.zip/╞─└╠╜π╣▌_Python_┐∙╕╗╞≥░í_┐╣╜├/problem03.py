def menu_count(restorant):
    pass
    # 여기에 코드를 작성합니다.
    

# 아래의 코드는 수정하지 않습니다.
if __name__ == '__main__':
    restorant = {
        "id": 11,
        "user_rating": 5.5,
        "name": "김밥나라",
        "menus": ["참치김밥", "치즈라면", "돈까스", "비빔밥"],
        "location": "서울특별시 강남구 역삼동 123-123"
    }
    print(menu_count(restorant)) # 4
